def plus(a, b):
    return a + b