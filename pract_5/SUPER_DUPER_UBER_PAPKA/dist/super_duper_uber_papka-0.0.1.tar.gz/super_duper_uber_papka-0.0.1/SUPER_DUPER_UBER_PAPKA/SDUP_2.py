def minus(a, b):
    return a - b