import setuptools
setuptools.setup(
    name='SUPER_DUPER_UBER_PAPKA',
    version='0.0.1',
    author='AkitaPTS',
    author_email='vendiedonn@gmail.com',
    description='My PACKET',
    packages=setuptools.find_packages(),
)